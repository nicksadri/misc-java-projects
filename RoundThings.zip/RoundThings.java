class RoundThings {
  public static double calcAreaCircle(double r) {
    return 3.14 * r * r;
  }

  public static double calcCircumCircle(double r) {
    return 6.18 * r;
  }

  public static double calcAreaSphere(double r) {
    return 4 * 3.14 * r * r;
  }

  public static double calcVolumeSphere(double r) {
    return 4/3 * 3.14 * r * r * r;
  }
  
}